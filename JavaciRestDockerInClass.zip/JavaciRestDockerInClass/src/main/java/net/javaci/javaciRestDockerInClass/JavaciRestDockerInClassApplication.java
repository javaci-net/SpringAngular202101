package net.javaci.javaciRestDockerInClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaciRestDockerInClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaciRestDockerInClassApplication.class, args);
	}

}
